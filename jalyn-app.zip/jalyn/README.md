# JALYN — gas flares from space → gas volume → tenge → the technology that stops the flaring

**What it is.** A web platform that finds persistent gas flares in NASA FIRMS satellite detections,
estimates how much gas each one burns, converts that into money and CO₂, matches a utilization
technology (modular methanol, gas-to-power, mini-LNG, reinjection) with its payback, and drafts the
gas-utilization program an operator has to file.

**Why.** 167 billion m³ of gas was flared worldwide in 2025 (World Bank, Global Gas Flaring Tracker 2026).
Kazakhstan has cut flaring by 87% since 2012, but the remaining sites are small and remote — a pipeline
does not pay off there. Meanwhile oil companies import methanol and pay for emissions. JALYN turns
"gas is burning somewhere" into a decision: this site, this many m³ per year, this much tenge, this
technology, this payback.

## How it works

```
NASA FIRMS (VIIRS, night detections)  →  0.015° grid  →  cells lit on ≥35% of nights = flares
        FRP (MW of radiation)  →  ÷0.25 (radiant fraction)  →  ÷36 MJ/m³  →  m³/s  →  m³/year
        m³/year  →  methanol (÷1,100 m³/t × ₸250,000/t) · electricity (3.5 kWh/m³ × ₸25) · CO₂-eq (2.57 kg/m³)
        m³/year  →  technology catalog  →  CAPEX, net income, payback
```

The method is the one behind the World Bank's Global Gas Flaring Tracker (VIIRS data, persistence over time).
The volume estimate is a screening estimate calibrated against the operator's flow meter. Every coefficient
lives in `app/economics.py`.

## Layout

```
app/
  main.py            FastAPI: API + static frontend, SQLite for subscriptions, HTML report
  firms.py           FIRMS Area API client (10-day windows) and persistent-cell clustering
  economics.py       flare physics, prices, CO₂, technology matching (all assumptions in one place)
  technologies.json  utilization technology catalog with CAPEX / OPEX / revenue (assumptions)
  demo_sites.json    DEMO points — synthetic, used only when no FIRMS key is set
static/
  index.html, styles.css, app.js   frontend: Leaflet map, KPIs, site cards, matching, subscription
  vendor/            Leaflet 1.9.4 and a Natural Earth country layer (map works without external tiles)
tools/record_demo.py the 60-second demo video, recorded automatically with Playwright
render.yaml          one-click deploy on Render
```

## Run locally

```bash
pip install -r requirements.txt
export FIRMS_MAP_KEY=your_key      # optional; without it the app runs in demo mode
uvicorn app.main:app --reload --port 8000
# open http://localhost:8000
```

The NASA FIRMS key is free and takes a minute: https://firms.modaps.eosdis.nasa.gov/api/area/

## Deploy — two options

**Option 1 · Render (full app: backend + database), 5 minutes**
1. Push the repository to GitHub (public).
2. render.com → New → **Blueprint** → pick the repository; Render reads `render.yaml`.
3. Add `FIRMS_MAP_KEY` under Environment for live data. Without it the service runs in demo mode.
4. After the build you get a link like `https://jalyn.onrender.com`.

**Option 2 · GitHub Pages (frontend only, no server), 2 minutes**
The same frontend runs as a static site: `index.html` at the repository root loads `static/static-fallback.js`,
which carries the demo data and a JavaScript copy of the formulas from `app/economics.py`. In this mode the badge
reads "DEMO DATA · STATIC"; subscriptions and the PDF report need the backend and say so.
1. Repository → Settings → Pages → Source: *Deploy from a branch* → Branch: `main`, folder `/ (root)` → Save.
2. The link appears within a minute: `https://<username>.github.io/jalyn/`.

## API

| Method | Path | What it does |
|---|---|---|
| GET | `/api/health` | status, whether live mode is available |
| GET | `/api/flares?mode=auto\|demo\|live&days=60` | flares with economics and totals |
| GET | `/api/technologies` | technology catalog |
| GET | `/api/sites/{id}/economics` | technology matching and payback for a site |
| GET | `/api/sites/{id}/report` | HTML draft of the gas-utilization program (print → PDF) |
| POST | `/api/subscriptions` | start monitoring a site (stored in SQLite) |
| GET | `/api/subscriptions` | list subscriptions |
| GET | `/docs` | Swagger — a quick way to show the jury the backend is real |

## Data modes — plainly

* **LIVE** — `FIRMS_MAP_KEY` is set: real VIIRS detections for the selected window, clustered on the fly, cached for 6 hours.
* **DEMO** — no key: 12 synthetic points in Kazakhstan's oil regions with plausible FRP values.
  They are not tied to real fields or companies and are marked with a "DEMO DATA" badge in the UI.

## Demo video (60 seconds)

`tools/record_demo.py` records the product walkthrough automatically (Playwright), then mixes in a synthesized
ambient bed plus click and key sounds (`tools/make_audio.py`, NumPy/SciPy — no downloaded samples, nothing to license):

```bash
pip install playwright numpy scipy && playwright install chromium
python tools/make_audio.py audio                                  # music.wav, click.wav, key0..2.wav
JALYN_BASE=https://your-deploy.onrender.com python tools/record_demo.py   # output: video/JALYN-demo.mp4
```

Walkthrough: flare map and KPIs → the largest site → gas, methanol, tenge, CO₂ → technology matching → subscription
(written to the database) → utilization program report → method and assumptions.

## Limits

* FRP-based volume is coarse (±50% and worse under clouds): a screening and prioritisation tool, not metering.
* Methanol and electricity prices and technology CAPEX are assumptions, kept in code and shown in the UI.
* Render's free tier sleeps without traffic: open the link a minute before the demo.
